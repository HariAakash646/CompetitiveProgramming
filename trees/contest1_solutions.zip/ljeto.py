n = int(input())
last = [-100]*8
s = [0, 0]
for i in range(n):
    t, a, b = map(int, input().split())
    a-=1
    b-=1
    s[a > b] += 100
    if t - last[a] <= 10:
        s[a > b] += 50
    last[a] = t
print(*s)

